<footer>
    Todos los derechos reservados - JG Carrillo &copy;
</footer>

</body>
</html>
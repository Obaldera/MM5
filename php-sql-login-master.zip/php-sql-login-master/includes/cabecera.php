<header>
    <a href="index.php">INICIO</a>
</header>